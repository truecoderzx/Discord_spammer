# Discord-SPAMMER
Free and Open Source discord bot

# TUTORIAL VIDEO HERE : https://www.youtube.com/watch?v=chCVwipytNA
YOU NEED TO INSTALL PYTHON FIRST : https://www.python.org/downloads/

Go to the discord developer portal: https://discord.com/developers/applications/

Creates a new application copy the token and turn on intents: 
"Intention of server members" & 
"Intent of message content"

Add the app to your discord app 

Start the install-requirement.bat after you can start the raider

The command is /spamraid 


https://jacko.lol

